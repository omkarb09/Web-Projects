function validate()
{
    var username=document.getElementById("username").value;
    var passwd=document.getElementById("password").value;
    
    if(username == "")
    {
        document.getElementById("usrnm").innerHTML = "Please enter username!";
        return false;
    }
    if(passwd=="")
    {
        //alert("Password cannot be blank");
        document.getElementById("passwd").innerHTML = "Please enter password!";
        return false;
    }
    if(document.getElementById("address").value=="")
    {
        document.getElementById("addr").innerHTML="Please enter address";
        return false;
    }
    /*if(document.getElementById("chckbox").checked==false)
    {
        document.getElementById("chck").innerHTML="Please select atleast one training program";
        return false;
    }*/
    if(document.getElementById("group").checked==false)
    {
        document.getElementById("grp").innerHTML="Please select one group";
        return false;
    }
    if(document.getElementById("likeToAttend").value=="")
    {
        document.getElementById("list").innerHTML="Please select one training program to attend";
        return false;
    }
    if(document.getElementById("image").value=="")
    {
        document.getElementById("img").innerHTML="Please file to upload";
        return false;
    }
        var form =document.getElementById("frm");
        form.action="Home.html";
        form.submit();
    
}