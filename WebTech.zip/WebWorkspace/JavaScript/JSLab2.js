function cintrest()
{
    var p=document.getElementById("principal").value;
    var r=document.getElementById("rate").value;
    var n=document.getElementById("year").value;
    var result;
    var temp=Math.pow((1+(r/100)),n);
    result=(p*(1+temp))-p;

    document.getElementById("result").innerHTML=result;
}