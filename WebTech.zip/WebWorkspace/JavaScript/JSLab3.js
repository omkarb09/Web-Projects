function name() {
    var employees=["Tove","Hege","Stale","Kai Jim","Borge","undefined"];
    var str="";
    for (index = 0; index < employees.length; index++)
    {
        str=str+(index+1)+". "+employees[index]+"<br>";    
    }
    document.getElementById("names").innerHTML=str;
}