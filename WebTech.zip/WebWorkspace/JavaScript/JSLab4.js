function compute()
{
    var p=document.getElementById("loan").value;
    var r=document.getElementById("rate").value;
    var n=document.getElementById("period").value;

    if(p>1500000)
    {
        document.getElementById("lbloan").innerHTML="Loan cannot be more than 15 lakh";
        
    }
    else if((n<7) || (n>15))
    {
        document.getElementById("lbperiod").innerHTML="Period can be between 7 to 15 years";
    
    }
    else
    {
        r=(r/12)/100;
        n=n*12;
        var temp1=Math.pow((1+r),n);
        var temp2=(Math.pow((1+r),n))-1

        var emi=(p*r*temp1)/temp2;

        var totalPayment=emi*n;

        var totalInterst=totalPayment-p;

        document.getElementById("monthlyPay").value=emi;
        document.getElementById("totalPay").value=totalPayment;
        document.getElementById("totalInt").value=totalInterst;
    }
    

}