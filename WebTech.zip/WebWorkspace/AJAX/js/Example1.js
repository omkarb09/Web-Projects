function populateProducts()
{
    var e = document.getElementById("category");
    var strCategory = e.options[e.selectedIndex].value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET','product.json',true);
    xhr.responseType='text';
    xhr.send();

  
    xhr.onload= function()
    {
        if(xhr.status==200)
        {
            var data=JSON.parse(xhr.responseText);
            var strOptions="";
            //alert(data);
            if(strCategory=="electronics")
            {
                for(i=0;i<data.electronics.length;i++)
                {
                    //alert(data.electronics[i].Product);
                    var temp ="<option>"+data.electronics[i].Product+"</option>";
                    strOptions=strOptions+temp;
                }    
            }
            else if(strCategory=="grocery")
            {
                for(i=0;i<data.grocery.length;i++)
                {
                    //alert(data.grocery[i].Product);
                    var temp ="<option>"+data.grocery[i].Product+"</option>";
                    strOptions=strOptions+temp;
                } 
            }
            document.getElementById("product").innerHTML=strOptions;
        }   
    }
}



function calPrice() 
{
    var quantity=getElementById("quantity").value;

    var e=document.getElementById("product");
    var product=e.options[e.selectedIndex].value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET','product.json',true);
    xhr.responseType='text';
    xhr.send();

    xhr.onload= function()
    {
        
        if(xhr.status==200)
        {
            var data=JSON.parse(xhr.responseText);
            var totalprice=0;

            for(i=0;i<data.electronics.length;i++)
            {
                if(data.electronics[i].Product==product)
                {
                    totalprice=quantity*data.electronics[i].Price;
                }
            }
            /*for(i=0;i<data.grocery.length;i++)
            {
                if(data.grocery[i].Product==product)
                {
                    totalprice=quantity*data.grocery[i].Price;
                }
            }*/
            document.getElementById("total").value=80000;
        }   
    }
}